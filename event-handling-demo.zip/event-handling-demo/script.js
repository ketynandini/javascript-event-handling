//DOM Access
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const logList = document.getElementById("logList");
const clearLog = document.getElementById("clearLog");

const clickBtn = document.getElementById("clickBtn");
const clickCount = document.getElementById("clickCount");

const keyInput = document.getElementById("keyInput");
const keyCap = document.getElementById("keyCap");
const keyMeta = document.getElementById("keyMeta");

const hoverZone = document.getElementById("hoverZone");
const hoverLabel = document.getElementById("hoverLabel");

const liveInput = document.getElementById("liveInput");
const charBadge = document.getElementById("charBadge");
const moodSelect = document.getElementById("moodSelect");
const livePreview = document.getElementById("livePreview");

const field1 = document.getElementById("field1");
const ring1 = document.getElementById("ring1");
const field2 = document.getElementById("field2");
const ring2 = document.getElementById("ring2");

const demoForm = document.getElementById("demoForm");
const nameField = document.getElementById("nameField");
const emailField = document.getElementById("emailField");
const submitBtn = document.getElementById("submitBtn");
const formResult = document.getElementById("formResult");

// ── State
let clicks = 0;
let liveText = "";
let mood = "";
let statusTimeout;

// ── Helpers
function timestamp() {
  const now = new Date();
  return now.toTimeString().slice(0, 8);
}

function log(type, message) {
  // Remove empty placeholder if present
  const empty = logList.querySelector(".log-empty");
  if (empty) empty.remove();

  const li = document.createElement("li");
  li.className = "log-item";
  li.innerHTML = `
    <span class="log-time">${timestamp()}</span>
    <span class="log-tag tag-${type}">${type}</span>
    <span class="log-msg">${message}</span>
  `;
  logList.prepend(li);

  // Keep log to 50 entries
  while (logList.children.length > 50) {
    logList.removeChild(logList.lastChild);
  }
}

function pulse(label, hot = false) {
  statusDot.className = "dot " + (hot ? "hot" : "active");
  statusLabel.textContent = label;
  clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => {
    statusDot.className = "dot";
    statusLabel.textContent = "Waiting…";
  }, 1800);
}

function lightWidget(el) {
  el.classList.add("lit");
  setTimeout(() => el.classList.remove("lit"), 500);
}

// click
clickBtn.addEventListener("click", () => {
  clicks++;
  clickCount.textContent = clicks;
  clickCount.classList.remove("bump");
  void clickCount.offsetWidth;
  clickCount.classList.add("bump");

  log("click", `Button clicked — total: <strong>${clicks}</strong>`);
  pulse(`click ×${clicks}`);
  lightWidget(document.getElementById("clickWidget"));
});

// keyup
keyInput.addEventListener("keyup", (e) => {
  const key = e.key === " " ? "SPC" : e.key.length > 1 ? e.key : e.key;
  const display = e.key === " " ? "⎵" : e.key.length === 1 ? e.key : e.key;

  keyCap.textContent = display.length > 3 ? display.slice(0, 3) : display;
  keyMeta.textContent = `key: "${e.key}" · code: ${e.code}`;

  keyCap.classList.remove("flash");
  void keyCap.offsetWidth;
  keyCap.classList.add("flash");

  log("keyup", `Key: <strong>"${e.key}"</strong> · code: ${e.code}`);
  pulse(`keyup: ${key}`);
  lightWidget(document.getElementById("keyWidget"));
});

// mouseover / mouseout 
hoverZone.addEventListener("mouseover", () => {
  hoverLabel.textContent = "Mouse is inside!";
  log("mouseover", "Mouse entered the hover zone");
  pulse("mouseover");
  lightWidget(document.getElementById("mouseWidget"));
});

hoverZone.addEventListener("mouseout", () => {
  hoverLabel.textContent = "Move mouse here";
  log("mouseout", "Mouse left the hover zone");
  pulse("mouseout");
});

// input 
liveInput.addEventListener("input", () => {
  liveText = liveInput.value;
  charBadge.textContent = liveText.length;

  updatePreview();
  log(
    "input",
    `Text: "<em>${liveText.slice(0, 40)}${
      liveText.length > 40 ? "…" : ""
    }</em>" (${liveText.length} chars)`
  );
  pulse("input");
  lightWidget(document.getElementById("inputWidget"));
});

// ── change ────────────────────────────────────────────────────
moodSelect.addEventListener("change", () => {
  mood = moodSelect.value;
  updatePreview();
  log("change", `Mood selected: <strong>${mood || "(none)"}</strong>`);
  pulse("change");
  lightWidget(document.getElementById("inputWidget"));
});

function updatePreview() {
  if (!liveText && !mood) {
    livePreview.textContent = "start typing…";
    livePreview.classList.remove("has-val");
    return;
  }
  const parts = [];
  if (liveText) parts.push(liveText);
  if (mood) parts.push(mood);
  livePreview.textContent = parts.join(" — ");
  livePreview.classList.add("has-val");
}

// ── focus / blur ──────────────────────────────────────────────
function attachFocusBlur(input, ringEl, label) {
  input.addEventListener("focus", () => {
    ringEl.textContent = "focused";
    ringEl.classList.add("on");
    log("focus", `"${label}" field focused`);
    pulse("focus");
    lightWidget(document.getElementById("focusWidget"));
  });

  input.addEventListener("blur", () => {
    ringEl.textContent = "—";
    ringEl.classList.remove("on");
    log("blur", `"${label}" field lost focus`);
    pulse("blur");
  });
}

attachFocusBlur(field1, ring1, "Username");
attachFocusBlur(field2, ring2, "Password");

// ── submit ────────────────────────────────────────────────────
demoForm.addEventListener("submit", (e) => {
  e.preventDefault(); // prevent default page reload

  const name = nameField.value.trim();
  const email = emailField.value.trim();

  formResult.classList.remove("show", "error");

  if (!name || !email) {
    formResult.textContent = "Please fill in both fields.";
    formResult.classList.add("show", "error");
    log("submit", "Validation failed — fields empty");
    pulse("submit", true);
    return;
  }

  formResult.textContent = `Submitted! Hello ${name} (${email})`;
  formResult.classList.add("show");

  log(
    "submit",
    `Form submitted — name: <strong>${name}</strong>, email: <strong>${email}</strong>`
  );
  pulse("submit ✓", false);
  lightWidget(document.getElementById("formWidget"));

  submitBtn.disabled = true;
  submitBtn.textContent = "Sent ✓";

  setTimeout(() => {
    demoForm.reset();
    formResult.classList.remove("show", "error");
    submitBtn.disabled = false;
    submitBtn.textContent = "Send →";
  }, 2500);
});

// ── clear log ─────────────────────────────────────────────────
clearLog.addEventListener("click", () => {
  logList.innerHTML = '<li class="log-empty">Log cleared.</li>';
});
